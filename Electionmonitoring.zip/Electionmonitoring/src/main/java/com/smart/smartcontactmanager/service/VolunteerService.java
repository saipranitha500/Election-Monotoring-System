package com.smart.smartcontactmanager.service;

import com.smart.smartcontactmanager.entities.Volunteer;

import java.util.List;


public interface VolunteerService {

    List<Volunteer> getAllVolunteers();
}
