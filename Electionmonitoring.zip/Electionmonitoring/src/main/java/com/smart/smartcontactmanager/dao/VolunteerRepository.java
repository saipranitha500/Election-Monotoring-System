package com.smart.smartcontactmanager.dao;

import com.smart.smartcontactmanager.entities.Volunteer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VolunteerRepository extends JpaRepository<Volunteer,Integer> {


}
